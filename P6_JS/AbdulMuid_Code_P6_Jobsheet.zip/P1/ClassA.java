public class ClassA {
    public int x;
    public int y;

    public void getNilai(){
        System.out.println("Nilai x: "+x);
        System.out.println("Nilai y: "+y);
    }
}
package P3;

public class Bangun {
    protected double phi;
    protected int r;
}

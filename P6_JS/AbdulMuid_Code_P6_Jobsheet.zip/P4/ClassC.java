package P4;

public class ClassC extends ClassB{
    ClassC(){
        super();
        System.out.println("Konstruktor C dijalankan");
    }
}

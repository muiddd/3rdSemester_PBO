package P4;

public class Percobaan4 {
    public static void main(String[] args) {
        ClassC test = new ClassC();
    }
}

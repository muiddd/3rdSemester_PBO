package P4;

public class ClassB extends ClassA{
    ClassB(){
        System.out.println("Konstruktor B dijalankan");
    }
}

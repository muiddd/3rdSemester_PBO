package P4;

public class ClassA {
    ClassA(){
        System.out.println("Konstruktor A dijalankan");
    }
}

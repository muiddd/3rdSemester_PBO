public class Kucing extends Hewan{

    @Override
    public void bergerak() {
        System.out.println("Berenang dengan SIRIP, \"wush..wush\"");
    }

}

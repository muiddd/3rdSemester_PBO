public class Ikan extends Hewan {

    @Override
    public void bergerak() {
        System.out.println("Berjalan dengan KAKI, \"tap..tap\"");
    }
    
}
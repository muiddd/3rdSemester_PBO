package Tugas;

public class Plant {
    public void doDestroy(Destroyable d) {
        d.destroyed();
    }
}

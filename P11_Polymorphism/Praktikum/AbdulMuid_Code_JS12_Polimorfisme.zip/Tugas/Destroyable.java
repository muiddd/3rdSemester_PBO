package Tugas;

public interface Destroyable {
    public abstract void destroyed();
}

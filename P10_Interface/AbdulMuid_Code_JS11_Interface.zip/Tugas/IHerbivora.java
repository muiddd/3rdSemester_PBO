package Tugas;

public interface IHerbivora {
    public abstract void displayMakan();
}

public class Mahasiswa extends Manusia{
    public void makan() { 
        System.out.println("Mahasiswa makan agar kuat mengerjakan tugas kuliah.");
    }

    public void tidur() {
        System.out.println("Mahasiswa butuh istirahat dan tidur.");
    }
}

public class Manusia {
    public void bernafas() { 
        System.out.println("Manusia perlu bernafas.");
    }

    public void makan() { 
        System.out.println("Manusia juga perlu makan.");
    }
}

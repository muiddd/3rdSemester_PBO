public class Dosen extends Manusia{
    public void makan() { 
        System.out.println("Dosen makan agar bisa mengajar dengan baik.");
    }

    public void lembur() { 
        System.out.println("Dosen sering lembur untuk menyelesaikan pekerjaan.");
    }
}
